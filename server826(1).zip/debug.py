from server import encryption,decryption
import time
start = time.time()
encryption(['0016.jpg'],'123456')
decryption(['0016.jpg'],'123456')
end = time.time()
print(end-start)